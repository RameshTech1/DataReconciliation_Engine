package com.example.Data.Reconciliation.Engine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataReconciliationEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
